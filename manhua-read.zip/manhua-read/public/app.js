const $ = (id) => document.getElementById(id);
let library = [];
let activeFilter = 'All';
const escapeHtml = (value = '') => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const statusLabel = (status) => ({FINISHED:'Finished',RELEASING:'Ongoing',NOT_YET_RELEASED:'Not yet released',CANCELLED:'Cancelled',HIATUS:'On hiatus',UNKNOWN:'Status unknown'}[status] || status || 'Status unknown');
async function api(url, options = {}) {
  const response = await fetch(url, { headers: { 'Content-Type':'application/json' }, ...options });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'Request failed');
  return data;
}
function setMessage(message) { $('search-message').textContent = message; }
function descriptionText(value) { const node = document.createElement('div'); node.innerHTML = value || ''; return node.textContent || ''; }
function renderResults(items) {
  const root = $('search-results'); root.innerHTML = '';
  for (const item of items) {
    const card = $('result-template').content.firstElementChild.cloneNode(true);
    card.querySelector('.poster').src = item.cover || '';
    card.querySelector('.poster').alt = `${item.title} cover`;
    card.querySelector('.format').textContent = item.format || 'MANGA';
    const badge = card.querySelector('.source-status'); badge.textContent = statusLabel(item.sourceStatus);
    if (item.sourceStatus === 'FINISHED') badge.classList.add('finished');
    card.querySelector('.title').textContent = item.title;
    card.querySelector('.description').textContent = descriptionText(item.description) || 'No description available.';
    card.querySelector('.card-meta').textContent = `${item.totalChapters ?? 'Unknown'} chapters · ${statusLabel(item.sourceStatus)}`;
    const add = card.querySelector('.add-button');
    add.addEventListener('click', async () => {
      add.disabled = true;
      try { await api('/api/library', { method:'POST', body:JSON.stringify({ ...item, currentChapter:0, readingStatus:'Plan to Read' }) }); await loadLibrary(); add.textContent = 'Added ✓'; setMessage(`${item.title} added to your library.`); }
      catch (error) { setMessage(error.message); add.disabled = false; }
    });
    root.append(card);
  }
}
$('search-form').addEventListener('submit', async (event) => {
  event.preventDefault(); const q = $('search-input').value.trim();
  if (!q) return setMessage('Type a title to search.');
  setMessage('Searching title database…'); $('search-results').innerHTML = '';
  try { const data = await api(`/api/search?q=${encodeURIComponent(q)}`); renderResults(data.results); setMessage(data.results.length ? `${data.results.length} matches found. Choose the correct title.` : 'No matches found. Try another spelling.'); }
  catch (error) { setMessage(error.message); }
});
function renderLibrary() {
  const root = $('library-grid'); root.innerHTML = '';
  const items = library.filter(item => activeFilter === 'All' || item.readingStatus === activeFilter);
  $('count-all').textContent = library.length;
  if (!items.length) { root.innerHTML = `<div class="empty-state">${library.length ? 'No titles in this filter yet.' : 'Your library is waiting for its first story. Search above to add one.'}</div>`; return; }
  for (const item of items) {
    const card = $('library-template').content.firstElementChild.cloneNode(true);
    card.querySelector('.poster').src = item.cover || ''; card.querySelector('.poster').alt = `${item.title} cover`;
    card.querySelector('.format').textContent = item.format || 'MANGA';
    const badge = card.querySelector('.source-status'); badge.textContent = statusLabel(item.sourceStatus); if (item.sourceStatus === 'FINISHED') badge.classList.add('finished');
    card.querySelector('.title').textContent = item.title;
    card.querySelector('.description').textContent = descriptionText(item.description) || 'No description available.';
    const total = item.totalChapters;
    card.querySelector('.chapter-line').textContent = `Chapter ${item.currentChapter} / ${total ?? '—'}`;
    const percent = total > 0 ? Math.min(100, item.currentChapter / total * 100) : 0;
    card.querySelector('.progress-fill').style.width = `${percent}%`;
    const chapter = card.querySelector('.chapter-input'); chapter.value = item.currentChapter; chapter.max = total || '';
    chapter.addEventListener('change', () => updateItem(item.id, { currentChapter:Math.max(0, Number(chapter.value) || 0) }));
    const status = card.querySelector('.reading-status'); status.value = item.readingStatus;
    status.addEventListener('change', () => updateItem(item.id, { readingStatus:status.value }));
    card.querySelector('.source-link').href = item.sourceUrl;
    card.querySelector('.remove-button').addEventListener('click', async () => { if (!confirm(`Remove ${item.title} from your library?`)) return; await api(`/api/library/${item.id}`, { method:'DELETE' }); await loadLibrary(); });
    root.append(card);
  }
}
async function updateItem(id, changes) { try { await api(`/api/library/${id}`, { method:'PATCH', body:JSON.stringify(changes) }); await loadLibrary(false); } catch (error) { alert(error.message); } }
async function loadLibrary(refresh = false) {
  try {
    if (refresh) { $('sync-label').textContent = 'Checking updates…'; try { await api('/api/refresh', { method:'POST', body:'{}' }); } catch (_) {} }
    const data = await api('/api/library'); library = data.items; renderLibrary();
    $('sync-label').textContent = `Synced ${new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}`;
  } catch (error) { $('sync-label').textContent = 'Server unavailable'; }
}
$('filters').addEventListener('click', event => { const button = event.target.closest('[data-filter]'); if (!button) return; activeFilter = button.dataset.filter; $('filters').querySelectorAll('button').forEach(b => b.classList.toggle('active', b === button)); renderLibrary(); });
loadLibrary(true);
// While the app is open, refresh AniList title metadata every 15 minutes.
setInterval(() => loadLibrary(true), 15 * 60 * 1000);
