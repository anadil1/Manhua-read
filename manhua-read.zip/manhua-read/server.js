const express = require('express');
const Database = require('better-sqlite3');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const ANILIST = 'https://graphql.anilist.co';
const db = new Database(path.join(__dirname, 'data', 'manhua-read.db'));
db.pragma('journal_mode = WAL');
db.exec(`CREATE TABLE IF NOT EXISTS library (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  media_id INTEGER NOT NULL UNIQUE,
  title TEXT NOT NULL,
  description TEXT,
  cover TEXT,
  format TEXT,
  total_chapters INTEGER,
  current_chapter INTEGER NOT NULL DEFAULT 0,
  source_status TEXT,
  reading_status TEXT NOT NULL DEFAULT 'Plan to Read',
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  metadata_checked_at TEXT
)`);

app.use(express.json({ limit: '100kb' }));
app.use(express.static(path.join(__dirname, 'public')));

const mediaFields = `id title { romaji english native } description(asHtml: false) coverImage { extraLarge large } chapters format status siteUrl`;
async function anilist(query, variables = {}) {
  const response = await fetch(ANILIST, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify({ query, variables })
  });
  if (!response.ok) throw new Error(`AniList returned ${response.status}`);
  const payload = await response.json();
  if (payload.errors?.length) throw new Error(payload.errors[0].message || 'AniList query failed');
  return payload.data;
}
function normalize(media) {
  return {
    mediaId: media.id,
    title: media.title?.english || media.title?.romaji || media.title?.native || 'Untitled',
    description: media.description || '',
    cover: media.coverImage?.extraLarge || media.coverImage?.large || '',
    format: media.format || 'MANGA',
    totalChapters: media.chapters ?? null,
    sourceStatus: media.status || 'UNKNOWN',
    sourceUrl: media.siteUrl || `https://anilist.co/manga/${media.id}`
  };
}

app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'Manhua Read' }));

app.get('/api/search', async (req, res) => {
  const term = String(req.query.q || '').trim().slice(0, 100);
  if (!term) return res.status(400).json({ error: 'Enter a title to search.' });
  try {
    const query = `query ($search: String) { Page(page: 1, perPage: 15) { media(search: $search, type: MANGA, sort: SEARCH_MATCH) { ${mediaFields} } } }`;
    const data = await anilist(query, { search: term });
    res.json({ results: (data.Page.media || []).map(normalize) });
  } catch (error) {
    res.status(502).json({ error: 'Could not search AniList right now. Please try again.' });
  }
});

app.get('/api/library', (_req, res) => {
  const rows = db.prepare('SELECT * FROM library ORDER BY updated_at DESC, id DESC').all();
  res.json({ items: rows.map(row => ({
    id: row.id, mediaId: row.media_id, title: row.title, description: row.description,
    cover: row.cover, format: row.format, totalChapters: row.total_chapters,
    currentChapter: row.current_chapter, sourceStatus: row.source_status,
    readingStatus: row.reading_status, updatedAt: row.updated_at,
    metadataCheckedAt: row.metadata_checked_at,
    sourceUrl: `https://anilist.co/manga/${row.media_id}`
  })) });
});

app.post('/api/library', (req, res) => {
  const item = req.body || {};
  const mediaId = Number(item.mediaId);
  if (!Number.isInteger(mediaId) || mediaId <= 0) return res.status(400).json({ error: 'Invalid title ID.' });
  const currentChapter = Math.max(0, Math.floor(Number(item.currentChapter) || 0));
  const readingStatus = ['Plan to Read', 'Reading', 'Completed', 'Dropped'].includes(item.readingStatus) ? item.readingStatus : 'Plan to Read';
  try {
    const result = db.prepare(`INSERT INTO library
      (media_id, title, description, cover, format, total_chapters, current_chapter, source_status, reading_status, updated_at)
      VALUES (@mediaId, @title, @description, @cover, @format, @totalChapters, @currentChapter, @sourceStatus, @readingStatus, CURRENT_TIMESTAMP)`)
      .run({ mediaId, title: String(item.title || 'Untitled').slice(0, 200), description: String(item.description || ''),
        cover: String(item.cover || ''), format: String(item.format || 'MANGA'), totalChapters: item.totalChapters == null ? null : Number(item.totalChapters),
        currentChapter, sourceStatus: String(item.sourceStatus || 'UNKNOWN'), readingStatus });
    res.status(201).json({ id: result.lastInsertRowid });
  } catch (error) {
    if (String(error.message).includes('UNIQUE')) return res.status(409).json({ error: 'This title is already in your library.' });
    res.status(500).json({ error: 'Could not save this title.' });
  }
});

app.patch('/api/library/:id', (req, res) => {
  const id = Number(req.params.id);
  const item = req.body || {};
  const current = db.prepare('SELECT * FROM library WHERE id = ?').get(id);
  if (!current) return res.status(404).json({ error: 'Title not found.' });
  const chapter = item.currentChapter === undefined ? current.current_chapter : Math.max(0, Math.floor(Number(item.currentChapter) || 0));
  const status = item.readingStatus === undefined ? current.reading_status : item.readingStatus;
  if (!['Plan to Read', 'Reading', 'Completed', 'Dropped'].includes(status)) return res.status(400).json({ error: 'Invalid reading status.' });
  db.prepare('UPDATE library SET current_chapter = ?, reading_status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?').run(chapter, status, id);
  res.json({ ok: true });
});

app.delete('/api/library/:id', (req, res) => {
  const result = db.prepare('DELETE FROM library WHERE id = ?').run(Number(req.params.id));
  if (!result.changes) return res.status(404).json({ error: 'Title not found.' });
  res.json({ ok: true });
});

// Refresh official title metadata on demand. The browser calls this periodically while open.
app.post('/api/refresh', async (_req, res) => {
  const rows = db.prepare('SELECT id, media_id FROM library').all();
  if (!rows.length) return res.json({ refreshed: 0 });
  try {
    let refreshed = 0;
    for (const row of rows) {
      const query = `query ($id: Int) { Media(id: $id, type: MANGA) { ${mediaFields} } }`;
      const data = await anilist(query, { id: row.media_id });
      if (!data.Media) continue;
      const m = normalize(data.Media);
      db.prepare(`UPDATE library SET title=?, description=?, cover=?, format=?, total_chapters=?, source_status=?, metadata_checked_at=CURRENT_TIMESTAMP WHERE id=?`)
        .run(m.title, m.description, m.cover, m.format, m.totalChapters, m.sourceStatus, row.id);
      refreshed++;
    }
    res.json({ refreshed, checkedAt: new Date().toISOString() });
  } catch (error) {
    res.status(502).json({ error: 'Metadata refresh failed. Existing library data was kept.' });
  }
});

app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.listen(PORT, () => console.log(`Manhua Read running at http://localhost:${PORT}`));
