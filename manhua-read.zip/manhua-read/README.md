# Manhua Read

A responsive reading-library web app for manhua, manhwa and manga. It fetches title metadata on the server, stores your reading list in SQLite, and refreshes publication information while the app is open.

## Features

- Search AniList's manga catalogue from the server (the browser never calls AniList directly).
- Automatically display cover art, title description, format, chapter count and publication status.
- Distinguish source publication status (ongoing, finished, hiatus, cancelled, etc.) from your personal reading status.
- Track current chapter and reading status: Reading, Plan to Read, Completed or Dropped.
- Persist the library in a local SQLite database instead of browser-only storage.
- Refresh title metadata on app startup and every 15 minutes while the app is open.
- Responsive dark interface.

## Requirements

- Node.js 20 or newer
- npm

## Run locally

```bash
npm install
npm start
```

Open http://localhost:3000.

## Data and metadata

- AniList provides title metadata and cover images. Its API is accessed by `server.js`.
- Your reading list and progress are stored in `data/manhua-read.db`.
- The SQLite database is intentionally excluded from Git by `.gitignore`.
- Metadata refresh runs when the app starts and every 15 minutes while a browser session is open. AniList status reflects the latest data available from AniList; it is not a guarantee of instantaneous publisher updates.

## API

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Health check |
| GET | `/api/search?q=title` | Search title metadata |
| GET | `/api/library` | List saved titles |
| POST | `/api/library` | Add a title |
| PATCH | `/api/library/:id` | Update chapter or reading status |
| DELETE | `/api/library/:id` | Remove a title |
| POST | `/api/refresh` | Refresh title metadata from AniList |

## Deploy

Deploy to a Node.js host that supports persistent disk storage, because SQLite writes to `data/manhua-read.db`. Set `PORT` if your host requires a custom port. For multiple users, add authentication and user-scoped library records before public deployment; this starter version is a single shared library.

## Credits

Title metadata is provided by [AniList](https://anilist.co/). Manhua Read is an independent project and is not affiliated with AniList.
